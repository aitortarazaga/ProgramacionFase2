
package Clases;

import java.util.Calendar;
import java.util.Date;


public class Logistica extends Persona{

    public Logistica(String dni, String nombre, String apellido1, String apellido2, String calle, int piso, String mano, String portal, String telMovil, String telPers, float salario, Date fecha_nac) {
        super(dni, nombre, apellido1, apellido2, calle, piso, mano, portal, telMovil, telPers, salario, fecha_nac);
    }

    
    
}
